Place your real assets here. Required names (case‑sensitive):
- assets/trio.mp4                           (home hero video)
- assets/ajin.webp, assets/migou.webp, assets/gungun.webp
- assets/trio2.webp … assets/trio10.webp    (gallery; no trio1, no 'gelly')
- assets/ajin_5s.mp4, assets/migou_5s.mp4, assets/gungun.mp4
Sounds (optional but referenced):
- assets/sounds/click.wav, send.wav, ambient.wav
- assets/sounds/ajin_reply.wav, migou_reply.wav, gungun_reply.wav
