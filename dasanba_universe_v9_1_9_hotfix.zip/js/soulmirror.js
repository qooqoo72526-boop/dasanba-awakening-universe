
document.addEventListener('DOMContentLoaded', ()=>{
  const list = document.getElementById('qList');
  const qs = Array.from({length:25}).map((_,i)=> `#${i+1} 星塵提問 — 你最近讓自己驕傲的一件小事？`);
  qs.forEach(t=>{
    const p=document.createElement('div'); p.className='q'; p.textContent = t; list.appendChild(p);
  })
  document.getElementById('analyze')?.addEventListener('click', ()=>{
    alert('已送出到 /api/chat (請用你的現有後端接續處理)');
  });
});
