
// Lightweight bubble + soft shimmer on arrival + audio hooks
function play(id){ const a=document.getElementById(id); if(a){ a.currentTime=0; a.play(); } }
function addBubble(side, text, who=''){
  const col = document.querySelector('.chat-col');
  const b = document.createElement('div');
  b.className = 'bubble ' + (side==='you'?'you':'they');
  b.innerHTML = (who? `<strong>${who}：</strong>`:'') + text;
  col.appendChild(b);
  b.scrollIntoView({behavior:'smooth', block:'end'});
}
document.addEventListener('DOMContentLoaded', ()=>{
  document.getElementById('sendBtn')?.addEventListener('click', ()=>{
    const input = document.getElementById('userInput');
    const text = (input.value || '').trim();
    if(!text) return;
    addBubble('you', text, 'You');
    play('sfxSend');
    // Here you will call your existing /api/chat.js with persona multiplexing
    // fetch('/api/chat.js', { ... })
    setTimeout(()=>{ addBubble('they', '收到—把你放在心上。', 'Ajin'); play('sfxAjin'); }, 800);
    setTimeout(()=>{ addBubble('they', '收到了。', 'Migou'); play('sfxMigou'); }, 1200);
    setTimeout(()=>{ addBubble('they', '收到了。', 'Gungun'); play('sfxGungun'); }, 1400);
    input.value = '';
  });
});
