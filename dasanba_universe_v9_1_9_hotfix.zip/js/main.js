
// STARFIELD + METEORS, irregular with occasional linger
const canvas = document.getElementById('starfield');
const ctx = canvas.getContext('2d');
let W, H, stars = [], meteors = [];
function resize(){
  W = canvas.width = window.innerWidth;
  H = canvas.height = window.innerHeight;
}
window.addEventListener('resize', resize); resize();

function initStars(count=140){
  stars = Array.from({length:count}).map(()=> ({
    x: Math.random()*W, y: Math.random()*H,
    r: Math.random()*1.1 + .3, a: Math.random(), s: Math.random()*0.6 + 0.2
  }));
}
function drawStars(){
  ctx.clearRect(0,0,W,H);
  ctx.fillStyle = 'rgba(255,255,255,0.9)';
  stars.forEach(st => {
    st.a += (Math.random()-0.5)*0.08;
    const alpha = 0.35 + 0.35*Math.sin(st.a);
    ctx.globalAlpha = alpha;
    ctx.beginPath(); ctx.arc(st.x, st.y, st.r, 0, Math.PI*2); ctx.fill();
  });
  ctx.globalAlpha = 1;
  drawMeteors();
  requestAnimationFrame(drawStars);
}
function spawnMeteor(){
  const side = Math.random() < .5 ? 'left' : 'right';
  const x = side === 'left' ? -50 : W+50;
  const y = Math.random()*H*0.6 + 20;
  const vx = side === 'left' ? (2+Math.random()*3) : -(2+Math.random()*3);
  const vy = 0.6 + Math.random();
  const linger = Math.random() < .2; // sometimes lingers brighter
  meteors.push({x,y,vx,vy,len: 180+Math.random()*120, life: linger ? 90: 40, linger});
}
function drawMeteors(){
  meteors.forEach(m => {
    m.x += m.vx; m.y += m.vy; m.life--;
    const grad = ctx.createLinearGradient(m.x, m.y, m.x-m.vx*m.len, m.y-m.vy*m.len);
    grad.addColorStop(0, 'rgba(255,255,255,0.9)');
    grad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.strokeStyle = grad; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(m.x, m.y); ctx.lineTo(m.x-m.vx*m.len, m.y-m.vy*m.len); ctx.stroke();
  });
  meteors = meteors.filter(m => m.life>0);
}
initStars(160); drawStars();
// irregular schedule 3–7s with randomness
function scheduleMeteor(){
  spawnMeteor();
  const t = 3000 + Math.random()*4000;
  setTimeout(scheduleMeteor, t);
}
setTimeout(scheduleMeteor, 1200);

// GALLERY – load trio.webp~trio10.webp (no 1, no gelly)
function loadGallery(){
  const container = document.querySelector('.gallery .frame');
  if(!container) return;
  const img = document.createElement('img');
  container.appendChild(img);
  const files = [2,3,4,5,6,7,8,9,10].map(n=>`assets/trio${n}.webp`);
  let i = 0;
  function next(){
    img.src = files[i % files.length];
    i++; setTimeout(next, 5000);
  }
  next();
}

// NAV active highlight
function setActiveNav(){
  const map = {'index.html':'Home','cosmic-post-station.html':'Post','soulmirror.html':'Mirror'};
  const path = location.pathname.split('/').pop() || 'index.html';
  const key = map[path] || null;
  if(key){
    const el = document.querySelector(`.navbtn[data-key="${key}"]`);
    if(el){ el.style.outline = '1px solid rgba(255,255,255,.18)'; el.style.boxShadow = '0 0 26px rgba(170,210,255,.26)'; }
  }
}

document.addEventListener('DOMContentLoaded', ()=>{
  loadGallery();
  setActiveNav();
});
